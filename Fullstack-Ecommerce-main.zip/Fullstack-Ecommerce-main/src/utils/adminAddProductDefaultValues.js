export const defaultValues = {
	name: "",
	imageURL: "",
	price: 0,
	category: "",
	brand: "",
	description: "",
};
