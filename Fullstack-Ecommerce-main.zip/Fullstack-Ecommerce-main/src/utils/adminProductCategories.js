export const categories = [
	{ id: 1, name: "Laptop" },
	{ id: 2, name: "Electronics" },
	{ id: 3, name: "Fashion" },
	{ id: 4, name: "Phone" },
	{ id: 5, name: "Jewelery" },
	{ id: 6, name: "Furniture" },
];
